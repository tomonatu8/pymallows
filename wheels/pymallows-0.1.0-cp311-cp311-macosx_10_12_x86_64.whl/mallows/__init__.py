from .mallows import *

__doc__ = mallows.__doc__
if hasattr(mallows, "__all__"):
    __all__ = mallows.__all__